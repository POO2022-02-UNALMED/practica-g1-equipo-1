
from enum import Enum

class Ahorro(Enum):
    ACTIVADO = 0
    ENCENDIDO = 1
    APAGADO = 2
    ROTO = 3
