
class Herramientas:

    def usar(self):
        pass
    def getName(self):
        pass
    def getDescription(self):
        pass
    def toString(self):
        pass
